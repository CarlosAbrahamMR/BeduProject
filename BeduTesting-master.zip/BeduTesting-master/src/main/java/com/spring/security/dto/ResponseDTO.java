package com.spring.security.dto;

import lombok.Data;

@Data
public class ResponseDTO {
    private int numOfErrors;
    private String message;
}
