package com.spring.security.model;

public enum Department {
    IT,
    HK,

}
