package com.spring.security.advice;

public class  NotFoundException extends java.lang.RuntimeException {


        public NotFoundException(long id) {
            super();
        }
    }

